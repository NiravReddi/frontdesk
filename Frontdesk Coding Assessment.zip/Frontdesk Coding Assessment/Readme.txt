To the hiring team and frontdesk

the recoding in the end od demo doesn't update automatically , i have added logic of addEventListener('click', async (event) 
to refresh whenever submit button is clicked . please do run the app and its components .

to run simply download the repo 

from Supervisor folder open the frontdesk.html and run the app.py (flask app) run it by using python -m flask run 


for the livekit agen setup the code

by installing live kit : 

brew install livekit-cli

connecting to livekit cloud : 

lk cloud auth

add the livekit-voice-agent after extraction 

and install dependencies : 

to add the uv package manager : https://docs.astral.sh/uv/getting-started/installation/#standalone-installer

uv add \
  "livekit-agents[silero,turn-detector]~=1.2" \
  "livekit-plugins-noise-cancellation~=0.2" \
  "python-dotenv"
  
 
 