from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct, Filter, FieldCondition, MatchValue
from livekit import agents

from livekit.agents import (Agent,
    AgentSession,
    JobContext,
    RunContext,
    ToolError,
    WorkerOptions,
    beta,
    cli,
    function_tool,
    RoomInputOptions,
    ChatContext, 
    ChatMessage,
    )
from datetime import datetime
import os
from livekit.plugins import noise_cancellation, silero
from livekit.plugins.turn_detector.multilingual import MultilingualModel
from livekit.agents import ChatContext, ChatMessage

load_dotenv(".env.local")




client = QdrantClient(
    url=os.getenv("QDRANT_URL"),
    api_key=os.getenv("QDRANT_API_KEY")
)

# Create collection if it doesn't exist
COLLECTION_NAME = "salon_queries"
VECTOR_SIZE = 384  # Choose appropriate size for your embeddings

def ensure_collection_exists():
    try:
        # Check if collection exists
        collections = client.get_collections().collections
        exists = any(c.name == COLLECTION_NAME for c in collections)
        
        if not exists:
            print(f"Creating collection {COLLECTION_NAME}...")
            # Create collection first
            client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(size=VECTOR_SIZE, distance=Distance.COSINE),
                on_disk_payload=True
            )
            
            # Then create indexes separately
            print("Creating indexes...")
            for field in ["type", "status", "timestamp"]:
                try:
                    client.create_payload_index(
                        collection_name=COLLECTION_NAME,
                        field_name=field,
                        field_schema="keyword"
                    )
                    print(f"Created index for {field}")
                except Exception as idx_error:
                    print(f"Warning: Could not create index for {field}: {str(idx_error)}")
            
            print(f"Collection {COLLECTION_NAME} setup completed")
            return True
        
        print(f"Collection {COLLECTION_NAME} already exists")
        return True
        
    except Exception as e:
        print(f"Error setting up collection: {str(e)}")
        return False

# Replace existing collection creation code with:
if not ensure_collection_exists():
    raise RuntimeError("Failed to setup Qdrant collection")
class Assistant(Agent):
    def __init__(self) -> None:
        super().__init__(
            instructions="""You are Bella, a virtual assistant for Hendriques Cuts salon..."""
        )

    
    

    async def on_user_message(self, message: ChatMessage, context: ChatContext):
        """Handle incoming user messages"""
        
        
        print(f"User said: {message.text}")
        
        if message.text.lower() == "show database":
            db_contents = await self.print_all_entries()
        else:
            db_contents = await self.lookup_salon_info(message.text)
            
        context.messages.append(ChatMessage(role="assistant", text=db_contents))
        await self.session.update_chat_ctx(context)
    
    


    
    @function_tool 
    async def lookup_salon_info(self, query: str) -> str:
        # Create dummy vector (replace with actual embedding in production)
        vector = [0.0] * VECTOR_SIZE
        
        # Search for answers
        results = client.search(
            collection_name=COLLECTION_NAME,
            query_vector=vector,
            query_filter=Filter(
                must=[FieldCondition(key="type", match=MatchValue(value="answer"))]
            ),
            limit=1
        )

        if results:
            return results[0].payload["text"]
        else:
            # If no answer found, store the query
            point = PointStruct(
                id=int(datetime.now().timestamp() * 1000),
                vector=vector,
                payload={
                    "type": "query",
                    "text": query,
                    "timestamp": datetime.now().isoformat(),
                    "status": "unresolved"
                }
            )
            client.upsert(
                collection_name=COLLECTION_NAME,
                points=[point]
            )
            return "Let me check that for you with the Supervisor. I've noted down your question and will get back to you soon, can I help with anything else in the meantime?"
    @function_tool
    async def print_all_entries(self) -> str:
        try:
            # Get queries
            queries = client.scroll(
                collection_name=COLLECTION_NAME,
                scroll_filter=Filter(
                    must=[FieldCondition(key="type", match=MatchValue(value="query"))]
                )
            )[0]
            
            # Get answers
            answers = client.scroll(
                collection_name=COLLECTION_NAME,
                scroll_filter=Filter(
                    must=[FieldCondition(key="type", match=MatchValue(value="answer"))]
                )
            )[0]
            
            output = []
            output.append("=== Unanswered Queries ===")
            for point in queries:
                output.append(f"Query: {point.payload['text']}")
                output.append(f"Timestamp: {point.payload['timestamp']}")
                output.append(f"Status: {point.payload.get('status', 'unknown')}\n")
                
            output.append("\n=== Stored Answers ===")
            for point in answers:
                output.append(f"Answer: {point.payload['text']}")
                output.append(f"Question: {point.payload.get('question', 'N/A')}")
                output.append(f"Timestamp: {point.payload['timestamp']}\n")
                
            return "\n".join(output)
        except Exception as e:
            print(f"Error retrieving entries: {str(e)}")
            return "Error retrieving database entries"
    
    async def on_end(self):
        print("Assistant session has ended.")
        return "Thank you for calling Hendriques Cuts salon. Have a great day!"
        
    

    

async def entrypoint(ctx: agents.JobContext):
        # Initialize session
        session = AgentSession(
            stt="assemblyai/universal-streaming:en",
            llm="openai/gpt-4.1-mini",
            tts="cartesia/sonic-2:9626c31c-bec5-4cca-baa8-f8ba9e84c8bc",
            vad=silero.VAD.load(),
            turn_detection=MultilingualModel(),
        )

        await session.start(
                room=ctx.room,
                agent=Assistant(),
                room_input_options=RoomInputOptions(
                    noise_cancellation=noise_cancellation.BVC(),
                ),
            )

    

    
    


if __name__ == "__main__":
    # Add debug logging
    import logging
    logging.basicConfig(level=logging.DEBUG)
    
    # Run with worker options - remove timeout parameter
    agents.cli.run_app(
        agents.WorkerOptions(
            entrypoint_fnc=entrypoint
        )
    )
    