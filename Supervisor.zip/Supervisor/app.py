
from dotenv import load_dotenv
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue, PointStruct
from qdrant_client import QdrantClient, models
from flask import Flask, jsonify, request
from flask_cors import CORS
import os
from datetime import datetime
# Load environment variables
load_dotenv(".env.local")
VECTOR_SIZE = 384  # 
QDRANT_URL = os.getenv("QDRANT_URL")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "salon_queries")

if not QDRANT_URL or not QDRANT_API_KEY:
    raise RuntimeError("Set QDRANT_URL and QDRANT_API_KEY in .env.local")
# Initialize Qdrant client
client = QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)

app = Flask(__name__)
CORS(app)


# Get all the entries in the 'salon_queries' collection
@app.route("/get-all", methods=["GET"])
def get_all():
    """ 
    GET /get-all
      query params:
        - limit (int, optional) default=1000
    Returns JSON array of points (id and payload).
    """
    try:
        

        # Get all the entries in the collection
        raw = client.scroll(
            collection_name=COLLECTION_NAME
        )

        records = raw[0] if isinstance(raw, tuple) and len(raw) > 0 else raw
        # unpack records to json
        def _to_json(rec):
            if isinstance(rec, dict):
                rid = rec.get("id")
                payload = rec.get("payload") or {}
            else:
                rid = getattr(rec, "id", None)
                payload = getattr(rec, "payload", {}) or {}
            return {"id": rid, "payload": payload}

        items = [_to_json(r) for r in (records or [])]

        return jsonify({"count": len(items), "points": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Get all the query entries in the 'salon_queries' collection
@app.route("/get-query", methods=["GET"])
def get_query():
    """
    GET /get-query
      query params:
        - limit (int, optional) default=1000
    Returns JSON array of points (id and payload).
    """
    try:
        

        # Get all the query entries in the collection
        raw = client.scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(
                must=[
                    FieldCondition(
                        key="type",
                        match=MatchValue(value="query")
                    )
                ]
        )
        )

        records = raw[0] if isinstance(raw, tuple) and len(raw) > 0 else raw
        # unpack records to json
        def _to_json(rec):
            if isinstance(rec, dict):
                rid = rec.get("id")
                payload = rec.get("payload") or {}
            else:
                rid = getattr(rec, "id", None)
                payload = getattr(rec, "payload", {}) or {}
            return {"id": rid, "payload": payload}

        items = [_to_json(r) for r in (records or [])]

        return jsonify({"count": len(items), "points": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Get all the answer entries in the 'salon_queries' collection
@app.route("/get-ans", methods=["GET"])
def get_ans():
    """
    GET /get-query
      query params:
        - limit (int, optional) default=1000
    Returns JSON array of points (id and payload).
    """
    try:
        

        # Get all the answer entries in the collection
        raw = client.scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(
                must=[
                    FieldCondition(
                        key="type",
                        match=MatchValue(value="answer")
                    )
                ]
        )
        )

        records = raw[0] if isinstance(raw, tuple) and len(raw) > 0 else raw
        # unpack records to json
        def _to_json(rec):
            if isinstance(rec, dict):
                rid = rec.get("id")
                payload = rec.get("payload") or {}
            else:
                rid = getattr(rec, "id", None)
                payload = getattr(rec, "payload", {}) or {}
            return {"id": rid, "payload": payload}

        items = [_to_json(r) for r in (records or [])]

        return jsonify({"count": len(items), "points": items})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
# Endpoint to post an answer to a query
@app.route("/post-answer", methods=["POST"])
def post_answer():
    """
    POST /post-answer
    """
    try:

        data = request.get_json(force=True)
        print("Received data:", data)  # Debug print
        # Extract fields from the request data
        text = data.get("text")
        question = data.get("question")
        query_id = data.get("query_id")

        # Debug prints
        print("Text:", text)
        print("Query ID:", query_id)

        if not text:
            return jsonify({"error": "Missing required field: text"}), 400
        if not query_id:
            return jsonify({"error": "Missing required field: query_id"}), 400

        ts = datetime.utcnow().isoformat()
        vector = [0.0] * VECTOR_SIZE
        # Construct the payload for the answer
        payload = {
            "type": "answer",
            "status": "resolved",
            "timestamp": ts,
            "text": text,
            "question": question
        }

        # Update the point in the collection
        client.upsert(
            collection_name=COLLECTION_NAME,
            points=[PointStruct(
                id=int(query_id),  # Ensure query_id is an integer
                vector=vector,
                payload=payload
            )]
        )

        return jsonify({"ok": True, "id": query_id, "payload": payload}), 200
    except Exception as e:
        print("Error:", str(e))  # Debug print
        return jsonify({"error": str(e)}), 500

# Endpoint to delete a query by its ID
@app.route("/delete-query/<int:query_id>", methods=["DELETE"])
def delete_query(query_id):
    try:
        # Use PointIdsList to specify points to delete
        client.delete(
            collection_name=COLLECTION_NAME,
            points_selector=models.PointIdsList(
                points=[query_id]
            )
        )
        return jsonify({"ok": True}), 204
    except Exception as e:
        return jsonify({"error": str(e)}), 500
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
