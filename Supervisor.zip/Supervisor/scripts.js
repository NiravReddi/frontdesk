

const contentEl = document.getElementById('content');
const navLinks = document.querySelectorAll('.nav-link');
// function to load overview data , from where supervisor can answer the queries and view unanswered queries
async function loadOverview() {
    contentEl.innerHTML = '<section class="loading"><p>Loading overview...</p></section>';
    try {
        const res = await fetch('http://localhost:5000/get-query', { cache: "no-store" });
        if (!res.ok) {
            const txt = await res.text();
            throw new Error(`Server returned ${res.status}: ${txt}`);
        }
        const data = await res.json();
        const items = data.points || [];

        if (items.length === 0) {
            contentEl.innerHTML = '<section><h2>Overview</h2><p>No queries found.</p></section>';
            return;
        }

        // Build table
        const tableHeader = `
            <h2>Overview — Unanswered Queries</h2>
            <p>Total: ${items.length}</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Text</th>
                        <th>Timestamp</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
        `;

        const rows = items.map(pt => {
            const id = pt.id ?? '';
            const payload = pt.payload ?? {};
            const type = payload.type ?? '';
            const text = escapeHtml(payload.text ?? '');
            const ts = payload.timestamp ?? '';
            const status = payload.status ?? '';
            return `
                <tr>
                    <td>${id}</td>
                    <td>${type}</td>
                    <td>${text}</td>
                    <td>${ts}</td>
                    <td>${status}</td>
                    <td><button class="answer-btn" data-id="${id}" data-text="${text}">Answer</button></td>
                </tr>
            `;
        }).join('');

        const tableFooter = `</tbody></table>`;
        contentEl.innerHTML = `<section>${tableHeader}${rows}${tableFooter}</section>`;
        
        // Add event listeners for answer buttons
        document.querySelectorAll('.answer-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const questionText = e.target.dataset.text;
                const questionId = e.target.dataset.id;
                showAnswerForm(questionText, questionId);
            });
        });
    } catch (err) {
        console.error('Overview load error', err);
        contentEl.innerHTML = `<section class="error"><h2>Error</h2><p>Could not load overview: ${err.message}</p></section>`;
    }
}
// function to show answer form and handle submission as POST request
function showAnswerForm(questionText, questionId) {
    // Remove any existing form first
    const old = document.querySelector('.answer-form');
    if (old) old.remove();

    const formHtml = `
        <div class="answer-form">
            <h3>Answer the Question</h3>
            <p><strong>Question:</strong> ${questionText}</p>
            <input type="text" id="answer-input" placeholder="Type your answer here..." required />
            <button id="submit-answer" data-id="${questionId}">Submit</button>
            <button id="cancel-answer">Cancel</button>
        </div>
    `;
    contentEl.insertAdjacentHTML('beforeend', formHtml);

    document.getElementById('submit-answer').addEventListener('click', async () => {
        const answerText = document.getElementById('answer-input').value;
        const id = parseInt(document.getElementById('submit-answer').dataset.id); // Ensure ID is a number

        if (!answerText) {
            alert("Please enter an answer.");
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/post-answer', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: answerText,
                    question: questionText,
                    query_id: id
                }),
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Failed to post answer: ${errorText}`);
            }

            document.querySelector('.answer-form').remove();
            await loadOverview();
        } catch (error) {
            alert('Error submitting answer: ' + error.message);
        }
    });

    document.getElementById('cancel-answer').addEventListener('click', () => {
        document.querySelector('.answer-form').remove();
    });

    // Add Enter-key support
    document.getElementById('answer-input').addEventListener('keydown', function(e){
        if (e.key === "Enter") {
            document.getElementById('submit-answer').click();
        }
    });
}

function escapeHtml(str) {
    if (!str && str !== 0) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}


// processing page loads 
async function loadPage(page) {
    
    contentEl.innerHTML = '<section class="loading"><p>Loading...</p></section>';
    try {
        const res = await fetch(`${page}.html`, { cache: "no-store" });
        if (!res.ok) throw new Error('Fetch failed');
        const html = await res.text();
        contentEl.innerHTML = html;
        
        runInlineScripts(contentEl);
        setActiveNav(page);
    } catch (err) {
        contentEl.innerHTML = `<section class="error"><h2>Error</h2><p>Could not load "${page}".</p></section>`;
        console.error('Load page error:', err);
    }
}

function setActiveNav(page) {
    navLinks.forEach(a => {
        a.classList.toggle('active', a.dataset.page === page);
    });
}


function runInlineScripts(container) {
    container.querySelectorAll('script').forEach(oldScript => {
        const script = document.createElement('script');
        if (oldScript.src) {
            script.src = oldScript.src;
        } else {
            script.textContent = oldScript.textContent;
        }
        document.body.appendChild(script);
        document.body.removeChild(script);
    });
}
// New function to load All Queries , That are in the database irrespective of status or type
async function loadAllQueries() {
    contentEl.innerHTML = '<section class="loading"><p>Loading all queries...</p></section>';
    try {
        const res = await fetch('http://localhost:5000/get-all', { cache: "no-store" });
        if (!res.ok) {
            const txt = await res.text();
            throw new Error(`Server returned ${res.status}: ${txt}`);
        }
        const data = await res.json();
        const items = data.points || [];

        if (items.length === 0) {
            contentEl.innerHTML = '<section><h2>All Queries</h2><p>No queries found.</p></section>';
            return;
        }

        const tableHeader = `
            <h2>All Queries</h2>
            <p>Total: ${items.length}</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Text</th>
                        <th>Timestamp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
        `;

        const rows = items.map(pt => {
            const id = pt.id ?? '';
            const payload = pt.payload ?? {};
            const type = payload.type ?? '';
            const text = escapeHtml(payload.text ?? '');
            const ts = payload.timestamp ?? '';
            const status = payload.status ?? '';
            return `
                <tr>
                    <td>${id}</td>
                    <td>${type}</td>
                    <td>${text}</td>
                    <td>${ts}</td>
                    <td>${status}</td>
                </tr>
            `;
        }).join('');

        const tableFooter = `</tbody></table>`;
        contentEl.innerHTML = `<section>${tableHeader}${rows}${tableFooter}</section>`;
    } catch (err) {
        console.error('All Queries load error', err);
        contentEl.innerHTML = `<section class="error"><h2>Error</h2><p>Could not load all queries: ${err.message}</p></section>`;
    }
}
// New function to load All Answers , That are in the database that have been answered or Is in answer status
async function loadAllAnswers() {
    contentEl.innerHTML = '<section class="loading"><p>Loading all Answers...</p></section>';
    try {
        const res = await fetch('http://localhost:5000/get-ans', { cache: "no-store" });
        if (!res.ok) {
            const txt = await res.text();
            throw new Error(`Server returned ${res.status}: ${txt}`);
        }
        const data = await res.json();
        const items = data.points || [];

        if (items.length === 0) {
            contentEl.innerHTML = '<section><h2>All Answers</h2><p>No Answers found.</p></section>';
            return;
        }

        const tableHeader = `
            <h2>All Answers</h2>
            <p>Total: ${items.length}</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Question</th>
                        <th>Text</th>
                        <th>Timestamp</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
        `;

        const rows = items.map(pt => {
            const id = pt.id ?? '';
            const payload = pt.payload ?? {};
            const type = payload.type ?? '';
            const text = escapeHtml(payload.text ?? '');
            const question = escapeHtml(payload.question ?? '');
            const ts = payload.timestamp ?? '';
            const status = payload.status ?? '';
            return `
                <tr>
                    <td>${id}</td>
                    <td>${type}</td>
                    <td>${question}</td>
                    <td>${text}</td>
                    <td>${ts}</td>
                    <td>${status}</td>
                </tr>
            `;
        }).join('');

        const tableFooter = `</tbody></table>`;
        contentEl.innerHTML = `<section>${tableHeader}${rows}${tableFooter}</section>`;
    } catch (err) {
        console.error('All Answers load error', err);
        contentEl.innerHTML = `<section class="error"><h2>Error</h2><p>Could not load all Answers: ${err.message}</p></section>`;
    }
}

// attach click handlers
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        if (page === 'all-queries') {
            loadAllQueries();  // Call the new function for All Queries
            setActiveNav('all-queries');
            history.pushState({ page }, '', `#${page}`);
            return;
        } else if (page === 'overview') {
            setActiveNav('overview');
            loadOverview();
            history.pushState({ page }, '', `#${page}`);
            return;
        }
        else if (page === 'answers') {
    setActiveNav('answers');
    loadAllAnswers();
    history.pushState({ page }, '', `#${page}`);
    return;
}
        loadPage(page);
        history.pushState({ page }, '', `#${page}`);
    });
});

// handle back/forward
window.addEventListener('popstate', (e) => {
    const page = (e.state && e.state.page) || location.hash.replace('#', '') || 'overview';
    if (page === 'overview') {
        loadOverview();
    } else {
        loadPage(page);
    }
});

contentEl.addEventListener('click', async (event) => {
    if (event.target && event.target.id === 'submit-answer') {
        event.preventDefault(); // prevents unexpected reloads
        const answerText = document.getElementById('answer-input').value;
        const id = parseInt(event.target.dataset.id);
        const questionText = document.querySelector('.answer-form p strong').nextSibling.textContent.trim();

        if (!answerText) {
            alert("Please enter an answer.");
            return;
        }

        try {
            console.log('Sending POST:', { text: answerText, question: questionText, query_id: id });

            const response = await fetch('http://localhost:5000/post-answer', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: answerText,
                    question: questionText,
                    query_id: id
                }),
            });

            if (!response.ok) throw new Error(await response.text());

            document.querySelector('.answer-form').remove();
            await loadOverview();
        } catch (err) {
            console.error('Submit error:', err);
            alert('Error submitting answer: ' + err.message);
        }
    }

    if (event.target && event.target.id === 'cancel-answer') {
        document.querySelector('.answer-form')?.remove();
    }
});

// initial load
document.addEventListener('DOMContentLoaded', () => {
    const initial = location.hash.replace('#', '') || 'overview';
    if (initial === 'overview') loadOverview();
    else if (initial === 'answers') loadAllAnswers();
    else loadPage(initial);
});